#include <stdio.h>

#include <sys/types.h>

#include <dirent.h>

void do_ls(char []);

main(int ac, char *av[])

{

	if ( ac == 1 )  // ac가 1일때 .을 넣어 줌

		do_ls( "." ); 

	else

		while ( --ac ){ //그렇지 않으면 ac를 1낮춘후 출력은 방금전것을 출력한다 

			printf("%s:n", *++av );

			do_ls( *av );

		}

}

void do_ls( char dirname[] )



{

	DIR *dir_ptr; /* 다이렉토리  */

	struct dirent *direntp; 

	if ( ( dir_ptr = opendir( dirname ) ) == NULL ) /* dir_ptr의 값이 널이면
		열수없다고 알려줌*/

		fprintf(stderr,"ls1: cannot open %sn", dirname);

	else

	{

		while ( ( direntp = readdir( dir_ptr ) ) != NULL ) /*null 이 아닌동안에
			파일명들을 출력해준다*/

			printf("%sn", direntp->d_name );

		closedir(dir_ptr);

	}

}
