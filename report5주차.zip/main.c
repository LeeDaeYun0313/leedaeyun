#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include "student.h"
void dbcreate(char *);
void dbquery(char *);
void dbupdate(char *);

int main(int argc, char *argv[]){
	int menu;

	if(argc < 2){
		fprintf(stderr, "사용법 : %s file\n", argv[0]);
		exit(1);
	}
	while(1){
		printf("Student program\n1. DB 생성\n2. DB 질의\n3. DB 갱신\n0.종료\n선택할 번호: ");
		scanf("%d", &menu);

		if(menu==1){
			dbcreate(argv[1]);
		}
		else if(menu==2){
			dbquery(argv[1]);
		}
		else if(menu==3){
			dbupdate(argv[1]);
		}
		else if(menu==0){
			exit(0);
		}
		else{
			printf("0~3 메뉴를 선택해주세요.");
		}
	}
}
